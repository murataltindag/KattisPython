#! python3

'''
Automated testing
Assignment: Messenger with file transfers
Test 1 for Java code

Tests included:
Does the program start? If not, perhaps the name is wrong?
Is a file transferred immediately?
Does the program end when stdin ends?
Does the program transfer the file correctly?
Does the program incorporate a file transfer protocol or merely attempt to transfer any file whose name matches the text of a message?
'''

import os, sys, time, subprocess, psutil, random
from within_file import WithinFile
from file_compare import FileCompare

def get_port(dup):
	tries = 0
	while tries < 3:
		port = random.randrange(1025, 65535)
		if port == dup:
			continue
		if not (port in [i.laddr.port for i in psutil.net_connections()]):
			print("using port", port)
			return port
		tries += 1
	print("No port available. Please try running the script later.")
	sys.exit()

withinFile= WithinFile()
compare= FileCompare()
cur_dir=os.getcwd()

shell_command= 'rm client/Ameca_splendens.jpg'
os.system( shell_command )
shell_command= 'rm client/DoNotTransfer.png'
os.system( shell_command )
shell_command= 'rm server/one-liners.txt'
os.system( shell_command )
shell_command= 'rm server/DoNotTransfer.txt'
os.system( shell_command )

program_name = 'MessengerWithFiles'
transfer_points= 0

#check whether the file is named correctly
try:
	file_stat= os.stat( program_name + '.class' )
except FileNotFoundError:
	print( program_name + '.class does not exist; the name of your program must match exactly' )
	sys.exit()
if file_stat.st_size == 0:
	print( 'Your program, ' + program_name + '.class, is an empty file' )
	sys.exit()

# Transfer file from server to client
#print( 'Transferring file from server to client...' )

# create blank input for the pipe to the server
args= ['py','-u','input-writer-cmds-messenger.py','7', '0', '0', 'server/blank.txt']
server_input_writer= subprocess.Popen( args, stdout=subprocess.PIPE)

port_srv = get_port(1025)
port_cli = get_port(port_srv + 1)

# start the program as a server
args= ['java','-cp', '..', program_name, '-l', str(port_srv) ]
server_output_text= open( 'server/server-recvd.txt', 'w' )
server_messenger= subprocess.Popen( args, stdin= server_input_writer.stdout, stdout=server_output_text, cwd= cur_dir + '/server')

time.sleep( 1 )

# create the input for the pipe to the client
args= ['py','-u','input-writer-cmds-messenger.py','1', '0', '6', 'client/client-file.txt']
client_input_writer= subprocess.Popen( args, stdout=subprocess.PIPE)

# start the program as a client
args= ['java','-cp', '..', program_name, '-l', str(port_cli), '-p', str(port_srv) ]
client_output_text= open( 'client/client-recvd.txt', 'w' )
client_messenger= subprocess.Popen( args, stdin= client_input_writer.stdout, stdout=client_output_text, cwd= cur_dir + '/client')

# check whether file was transferred immediately from server to client
time.sleep( 4 )
differ= compare.binFiles( 'client/Ameca_splendens.jpg', 'server/Ameca_splendens.jpg' )
if differ:
	print( 'The file Ameca_splendens.jpg was not transferred properly; your program must be revised. Pay close attention to detail.' )
	#server_messenger.kill()
	#client_messenger.kill()
	#sys.exit()
else:
	transfer_points= 1

# wait until the server input pipe closes; then, check whether the server process terminated
try:
	server_messenger.wait( 5 )
	if server_messenger.returncode != 0:
		print( 'server ' + program_name + ' returned: ' + str(server_messenger.returncode) + '; your program must be revised' )
		client_messenger.kill()
		sys.exit()
except subprocess.TimeoutExpired:
	print( 'server ' + program_name + ' has not exited within the expected timeframe; your program must be revised' )
	server_messenger.kill()
	client_messenger.kill()
	sys.exit()

# wait until the client input pipe closes; then, check whether the client process terminated
try:
	#client_messenger.wait( 2 )
	client_messenger.wait( 0 ) # computers are now able to close the connection quickly!
	if client_messenger.returncode != 0:
		print( 'client ' + program_name + ' returned: ' + str(client_messenger.returncode) + '; your program must be revised' )
		sys.exit()
except subprocess.TimeoutExpired:
	print( 'client ' + program_name + ' has not exited within the expected timeframe; your program must be revised' )
	client_messenger.kill()
	sys.exit()

# check whether file with name that matched message was transferred from server to client
differ= compare.binFiles( 'client/DoNotTransfer.png', 'server/DoNotTransfer.png' )
if not differ:
	print( 'Unrequested file was transferred in violation of the assignment rules; your program must be revised. Pay close attention to detail.' )
	sys.exit()

# Transfer file from client to server
#print( 'Transferring file from client to server...' )

# create the input for the pipe to the server
args= ['py','-u','input-writer-cmds-messenger.py','1', '0', '6', 'server/server-file.txt']
server_input_writer= subprocess.Popen( args, stdout=subprocess.PIPE)

port_srv = get_port(0)
port_cli = get_port(port_srv)

# start the program as a server
args= ['java','-cp', '..', program_name, '-l', str(port_srv) ]
server_output_text= open( 'server/server-recvd.txt', 'w' )
server_messenger= subprocess.Popen( args, stdin= server_input_writer.stdout, stdout=server_output_text, cwd= cur_dir + '/server')

time.sleep( 1 )

# create blank input for the pipe to the client
args= ['py','-u','input-writer-cmds-messenger.py','7', '0', '0', 'client/blank.txt']
client_input_writer= subprocess.Popen( args, stdout=subprocess.PIPE)

# start the program as a client
args= ['java','-cp', '..', program_name, '-l', str(port_cli), '-p', str(port_srv) ]
client_output_text= open( 'client/client-recvd.txt', 'w' )
client_messenger= subprocess.Popen( args, stdin= client_input_writer.stdout, stdout=client_output_text, cwd= cur_dir + '/client')

# check whether file was transferred immediately from client to server
time.sleep( 4 )
differ= compare.binFiles( 'server/one-liners.txt', 'client/one-liners.txt' )
if differ:
	print( 'The file one-liners.txt was not transferred properly; your program must be revised. Pay close attention to detail.' )
	#server_messenger.kill()
	#client_messenger.kill()
	#sys.exit()
else:
	transfer_points+= 1

# wait until the client input pipe closes; then, check whether the client process terminated
try:
	client_messenger.wait( 4 )
	if client_messenger.returncode != 0:
		print( 'client ' + program_name + ' returned: ' + str(client_messenger.returncode) + '; your program must be revised' )
		server_messenger.kill()
		sys.exit()
except subprocess.TimeoutExpired:
	print( 'client ' + program_name + ' has not exited within the expected timeframe; your program must be revised' )
	client_messenger.kill()
	server_messenger.kill()
	sys.exit()

# wait until the server input pipe closes; then, check whether the server process terminated
try:
	#server_messenger.wait( 2 )
	server_messenger.wait( 0 ) # computers are now able to close the connection quickly!
	if server_messenger.returncode != 0:
		print( 'server ' + program_name + ' returned: ' + str(server_messenger.returncode) + '; your program must be revised' )
		sys.exit()
except subprocess.TimeoutExpired:
	print( 'server ' + program_name + ' has not exited within the expected timeframe; your program must be revised' )
	server_messenger.kill()
	sys.exit()

# check whether file with name that matched message was transferred from client to server
differ= compare.binFiles( 'server/DoNotTransfer.txt', 'client/DoNotTransfer.txt' )
if not differ:
	print( 'Unrequested file was transferred in violation of the assignment rules; your program must be revised. Pay close attention to detail.' )
	sys.exit()

if transfer_points:
	print( 'test1 terminated properly' )
